document.addEventListener("DOMContentLoaded", function (event) {
  var myIndex = 0;
  carousel();

  function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";
    }
    myIndex++;
    if (myIndex > x.length) {
      myIndex = 1
    }
    x[myIndex - 1].style.display = "block";
  };

  setInterval(carousel, 2000);
  loadCalendarDays();

  function loadCalendarDays() {
    document.getElementsByClassName("calendarDays")[0].innerHTML = "";

    var tmpDate = new Date(2018, 5, 0);
    var num = daysInMonth(5, 2018);
    var dayofweek = tmpDate.getDay();
    var previousMonthLastDay = daysInMonth(4, 2018);     // find where to start calendar day of week

    for (var i = 0; i <= dayofweek; i++) {
      var d = document.createElement("div");
      d.classList.add("day");
      d.classList.add("blank");
      d.innerHTML = previousMonthLastDay - dayofweek + i;
      document.getElementsByClassName("calendarDays")[0].appendChild(d);
    }

    for (var i = 0; i < num; i++) {
      var tmp = i + 1;
      var d = document.createElement("div");
      d.id = "calendarday_" + i;
      d.className = "day";
      d.innerHTML = tmp;
      d.dataset.day = tmp;
      document.getElementsByClassName("calendarDays")[0].appendChild(d);
    }

    var clear = document.createElement("div");
    clear.className = "clear";
    document.getElementsByClassName("calendarDays")[0].appendChild(clear);
  }

  function daysInMonth(month, year) {
    var d = new Date(year, month + 1, 0);
    return d.getDate();
  }
})

function readMore() {
  var dots = document.getElementsByClassName("expanded-span")[0];
  var moreText = document.getElementsByClassName("expanded-content")[0];
  document.getElementsByClassName("beyond-streak")[0].style.height = "511px";
  dots.style.display = "none";
  dots.innerHTML = "";
  moreText.innerHTML = " smells with sleep and make them part of your bedtime ritual,â€ says Jade Wells, a Physiologist at Nuffield Health. She suggests reading, alongside other relaxing activities, such as taking a warm bath and inhaling a soothing scent like lavender, as part of a wind-down routine to help induce sleep.";
} 
